const Spacing: number = 10;

export default Spacing;
