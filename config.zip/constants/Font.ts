export default {
  "poppins-regular": "poppins-regular",
  "poppins-bold": "poppins-bold",
  "poppins-semiBold": "poppins-semiBold",
};
